#!/usr/bin/env python

from distutils.core import setup

setup(name='RecuperacionDI',
      version='1.0',
      description='Programa para DI',
      author='Juan Vázquez',
      author_email='jvazquezveloso@danielcastelao.org',
      url='danielcastelao.org',
      packages=['/home/oracle/Descargas/RecuperacionDI'],
     )